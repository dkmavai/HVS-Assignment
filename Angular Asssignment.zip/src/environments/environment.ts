// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

import { Page1Component } from 'src/app/components/page1/page1.component';
import { Page2Component } from 'src/app/components/page2/page2.component';
import { Page3Component } from 'src/app/components/page3/page3.component';

export const environment = {
  production: false,
  urls: [
    {path:'Page-1', component: Page1Component },
    {path:'Page-2', component: Page2Component },
    {path:'Page-3', component: Page3Component }
  ]

};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
