import { NgModule } from '@angular/core';
import { Routes, RouterModule, Router } from '@angular/router';
import { environment } from '../environments/environment';
import { AppComponent } from './app.component';

var routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
  configUrls: any[];
  constructor(private router: Router) {
    this.configUrls = environment.urls;
    let mainRoutes: any[] = [{
      path: '',
      component: AppComponent,
      pathMatch: 'full'
    }];
    const config = this.router.config;
    config.push({
      path: '',
      children: mainRoutes
    });
    if (this.configUrls && this.configUrls.length > 0) {
      this.configUrls.forEach(item => {
        config.push({ path: item.path, component: item.component });
      });
    }
    this.router.resetConfig(config);

  }
}