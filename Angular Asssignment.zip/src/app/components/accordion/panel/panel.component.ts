import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'panel',
  templateUrl: './panel.component.html',
  styleUrls: ['./panel.component.css']
})
export class PanelComponent{
  @Input() opened = false;
  @Input() title: string;
  @Input() url: string;
  @Output() toggle: EventEmitter<any> = new EventEmitter<any>();
  
  constructor(public router: Router) {}

  toggleView() {

    //toggle the opened state
    this.opened = !this.opened;

    // toggle the panels view as per the change
    this.toggle.emit(this.shouldOpen());
  }

  shouldOpen() {
    
    //check if the state is opened and router 
    //url is same as the link of the panel
    return this.opened && this.router.url.replace('/', '') == this.url;
  }
}