import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { environment } from '../environments/environment';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'HVS';
  urls: any;
  constructor() {
  }
  ngOnInit(){

    //Get the urls from config
    this.urls = environment.urls;
    
  }
}
